"""
Sample agent studio tool to showcase tool making capabilities. 
This tool receives a JSON-like payload from an LLM agent and stores it locally
in a specific directory, appending data incrementally to a single file.
"""

from pydantic import BaseModel, Field
from typing import Optional, Any
import json 
import argparse
import os

class UserParameters(BaseModel):
    """
    Parameters used to configure a tool. This may include API keys,
    database connections, environment variables, etc.
    """
    pass 

class ToolParameters(BaseModel):
    """
    Arguments of a tool call. These arguments are passed to this tool whenever
    an Agent calls this tool. 
    """

    agent_payload: dict = Field(
        description="A JSON object containing the structured data injected by the agent."
    )

def run_tool(config: UserParameters, args: ToolParameters) -> Any:
    """
    Main tool code logic. Saves the LLM's injected JSON to a specific folder
    incrementally by appending it to a single JSON array.
    """
    

    safe_file_name = "global_extractions.json"
        
    output_directory = "extracted_data"
    os.makedirs(output_directory, exist_ok=True)
    
    results_file = os.path.join(output_directory, safe_file_name)

 
    existing_data = []
    

    if os.path.exists(results_file):
        try:
            with open(results_file, "r") as f:
                content = json.load(f)
                # Assicuriamoci che il contenuto sia una lista
                if isinstance(content, list):
                    existing_data = content
                else:
                    existing_data = [content]
        except json.JSONDecodeError:
       
            existing_data = []
            

    existing_data.append(args.agent_payload)


    with open(results_file, "w") as f:
        json.dump(existing_data, f, indent=4)

    
    # Get artifact file directory for return value
    workspace_dir = os.path.abspath(output_directory)
    
    # Return results including artifact file paths
    result_object = {
        "status": "success",
        "message": f"Agent payload successfully appended in {results_file}",
        "artifacts_created": [
            {
                "file_name": safe_file_name,
                "file_path": os.path.abspath(results_file),
                "description": "JSON file containing the incremental inputs injected by the LLM agent"
            }
        ],
        "artifact_directory": workspace_dir,
        # Echo back the payload so the agent knows exactly what was saved this time
        "data_stored": args.agent_payload 
    }
    return result_object

OUTPUT_KEY = "tool_output"
"""
When an agent calls a tool, technically the tool's entire stdout can be passed back to the agent.
However, if an OUTPUT_KEY is present in a tool's main file, only stdout content *after* this key is
passed to the agent.
"""

if __name__ == "__main__":
    """
    Tool entrypoint. 
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-params", required=True, help="Tool configuration")
    parser.add_argument("--tool-params", required=True, help="Tool arguments")
    args = parser.parse_args()
    
    # Parse JSON into dictionaries
    user_dict = json.loads(args.user_params)
    tool_dict = json.loads(args.tool_params)
    
    # Validate dictionaries against Pydantic models
    config = UserParameters(**user_dict)
    params = ToolParameters(**tool_dict)
    
    # Run the tool.
    output = run_tool(config, params)
    
    # Print the structured output back to the agent
    print(OUTPUT_KEY, json.dumps(output))