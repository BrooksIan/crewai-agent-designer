"""
Tool to read the central JSON log file from a specified local directory
and return its contents to the calling LLM agent.
"""

from pydantic import BaseModel, Field
from typing import Optional, Any
import json 
import argparse
import os

class UserParameters(BaseModel):
    """Platform configuration parameters."""
    dummy_config: Optional[str] = Field(
        default="", 
        description="Dummy configuration to satisfy the platform's UI parser."
    )

class ToolParameters(BaseModel):
    """Tool execution parameters."""
    dummy_param: Optional[str] = Field(
        default="", 
        description="Dummy parameter to satisfy the platform's UI parser."
    )

def run_tool(config: UserParameters, args: ToolParameters) -> Any:
    """
    Main tool code logic. Reads the central 'estrazioni_globali.json' file 
    and returns the aggregated data array back to the agent.
    """
    directory = 'extracted_data'
    target_file = 'global_extractions.json'
    filepath = os.path.join(directory, target_file)
    
    if not os.path.exists(filepath):
        return {
            "status": "success",
            "message": f"File '{target_file}' does not exist yet. No data has been extracted.",
            "data_retrieved": []
        }
        
    retrieved_data = []
    
    try:
        with open(filepath, "r") as f:
            retrieved_data = json.load(f)
    except Exception as e:
        
        return {
            "status": "error",
            "message": f"Failed to read {target_file}: {str(e)}",
            "data_retrieved": []
        }
    
    result_object = {
        "status": "success",
        "message": f"Successfully read data from '{target_file}'.",
        # Restituiamo la lista di oggetti salvati fino a questo momento
        "data_retrieved": retrieved_data 
    }
    
    return result_object

OUTPUT_KEY = "tool_output"

if __name__ == "__main__":
    """
    Tool entrypoint. 
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-params", required=True, help="Tool configuration")
    parser.add_argument("--tool-params", required=True, help="Tool arguments")
    args = parser.parse_args()
    
    # Parse JSON into dictionaries
    user_dict = json.loads(args.user_params)
    tool_dict = json.loads(args.tool_params)
    
    # Validate dictionaries against Pydantic models
    config_obj = UserParameters(**user_dict)
    params_obj = ToolParameters(**tool_dict)
    
    # Run the tool
    output = run_tool(config_obj, params_obj)
    
    # Print the structured output back to the agent
    print(OUTPUT_KEY, json.dumps(output))