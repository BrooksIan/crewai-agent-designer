"""
This tool acts as an automated document extraction and Optical Character Recognition processing engine,
designed to convert unstructured document formats into clean, machine-readable text.
It supports both multi-page PDFs and standard image formats under 50 megabytes.

Pipeline (per page/image):
  0. PNG normalisation  — image is converted to PNG.
  1. Orientation check  — This avoids the "face is upright but card is rotated" false-NONE problem.
  2. Programmatic correction — Pillow applies the inverse transform if needed.
  3. OCR pass — corrected image is sent to the VLM for full transcription.

"""

from __future__ import annotations
import argparse
import base64
import io
import json
import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
import unicodedata

import fitz
from openai import OpenAI
from PIL import Image, ImageOps
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

IMAGE_EXTENSIONS: dict[str, str] = {
    ".jpg":  "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png":  "image/png",
    ".tiff": "image/tiff",
    ".tif":  "image/tiff",
}
SUPPORTED_EXTENSIONS = {".pdf", *IMAGE_EXTENSIONS}
DEFAULT_PDF_DPI = 300

ORIENTATION_LABELS = frozenset({"NONE", "FLIP_HORIZONTAL", "FLIP_VERTICAL", "ROTATE_180"})

# Input files are read from the tool's current working directory, which the
# engine sets to the per-run session directory. Uploaded files are synced here,
# so there is no need for a hardcoded absolute path or a caller-supplied id.

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

ORIENTATION_PROMPT = (
    "You are an image orientation classifier. "
    "Examine the text in this image and decide whether it is flipped or rotated "
    "compared to its correct reading orientation.\n\n"
    "Reply with EXACTLY ONE of the following labels and nothing else — "
    "no punctuation, no explanation, no whitespace before or after:\n\n"
    "  NONE               — text is already correctly oriented\n"
    "  FLIP_HORIZONTAL    — text is mirrored left-to-right\n"
    "  FLIP_VERTICAL      — text is flipped upside-down\n"
    "  ROTATE_180         — text is rotated 180 degrees\n\n"
    "Output only the label."
)

DEFAULT_OCR_PROMPT = (
    "You are an advanced OCR and document transcription engine. "
    "Transcribe all text content from this image exactly as it appears, "
    "preserving reading order, headings, lists, and tables using precise markdown formatting. "
    "CRITICAL INSTRUCTION FOR FORMS: You must explicitly detect and represent the state of all visual form elements. "
    "Use '[X]' for marked, checked, or filled checkboxes and radio buttons. "
    "Use '[ ]' for empty or unchecked checkboxes and radio buttons. "
    "If present, indicate non-textual elements using structural tags like '[Signature]' or '[Stamp]'. "
    "Do not summarize, translate, or add any conversational commentary — "
    "output strictly the transcribed markdown content. Try not hallucinate outputting garbage sequence of characters"
)


# ---------------------------------------------------------------------------
# Config / parameter models
# ---------------------------------------------------------------------------

class UserParameters(BaseModel):
    endpoint_url: str = Field(
        default=(
            "https://aead-cainf2.aead-mvp.a465-9q4k.cloudera.site/namespaces/serving-default/endpoints/qwen35-9b/openai/v1"
        )
    )
    api_key: Optional[str] = Field(default=os.environ.get("CDSW_APIV2_KEY", ""))
    model_name: str = Field(default="Qwen/Qwen3.5-9B")
    max_tokens: int = Field(default=2500)
    output_dir: str = Field(default="./ocr_outputs")
    pdf_dpi: int = Field(default=DEFAULT_PDF_DPI)
    prompt: str = Field(default=DEFAULT_OCR_PROMPT)
    temperature: float = Field(default=0.0)


class ToolParameters(BaseModel):
    file_name: str = Field(
        description="The exact name of the file to process (e.g. document.pdf)."
    )


# ---------------------------------------------------------------------------
# File utilities
# ---------------------------------------------------------------------------

def _resolve_file_path(file_name: str) -> str | None:
    # The tool's cwd is the per-run session directory; uploaded files are synced here.
    if os.path.exists(file_name):
        return os.path.abspath(file_name)

    # Fallback: NFC-normalised filename match within the session dir,
    # in case of unicode filename mismatches (e.g. accented characters
    # encoded differently by the uploading client vs. the filesystem).
    req_name_nfc = unicodedata.normalize("NFC", file_name)
    for f in os.listdir("."):
        if unicodedata.normalize("NFC", f) == req_name_nfc:
            return os.path.abspath(f)

    return None

'''

def _debug_dump_home_cdsw(output_dir: str, root: str = "/") -> str:
    """
    Debug helper: recursively lists all folders and subfolders under `root`
    (default "/", i.e. the whole server), writes it to a .txt file in
    output_dir, and prints it to stdout. Returns the path to the written
    file (or "" on failure).

    Pseudo/virtual filesystems that are huge, non-terminating, or require
    elevated permissions are skipped to keep this fast and safe.
    """
    SKIP_DIRS = {
        "/proc", "/sys", "/dev", "/run", "/snap",
        "/var/lib/docker", "/var/lib/containers",
    }

    lines: list[str] = [f"Folder listing for: {root}", f"Generated: {datetime.now().isoformat()}", "-" * 60]

    if not os.path.isdir(root):
        lines.append(f"!! Directory does not exist: {root}")
    else:
        def _on_error(err: OSError) -> None:
            lines.append(f"!! Permission/error skipped: {err.filename}")

        for dirpath, dirnames, _filenames in os.walk(root, onerror=_on_error, followlinks=False):
            # Prune skip-listed / hidden system dirs in place so os.walk doesn't descend into them
            dirnames[:] = [
                d for d in dirnames
                if os.path.join(dirpath, d) not in SKIP_DIRS
            ]

            depth = dirpath[len(root):].count(os.sep)
            indent = "  " * depth
            lines.append(f"{indent}{dirpath}/")

    listing_text = "\n".join(lines)

    print(listing_text)

    try:
        os.makedirs(output_dir, exist_ok=True)
        out_path = os.path.join(output_dir, "debug_home_cdsw_listing.txt")
        with open(out_path, "w", encoding="utf-8") as fh:
            fh.write(listing_text)
        return out_path
    except Exception as exc:
        print(f"!! Failed to write debug listing file: {exc}")
        return ""
'''

def _sanitize_filename(name: str) -> str:
    return re.sub(r"[^\w\-.]", "_", name)


def _save_artifact(output_dir: str, base_filename: str, text: str) -> str:
    os.makedirs(output_dir, exist_ok=True)
    stem     = _sanitize_filename(Path(base_filename).stem)
    out_path = os.path.join(output_dir, f"extracted_{stem}.txt")
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(text)
    return os.path.abspath(out_path)


# ---------------------------------------------------------------------------
# Image encoding helpers
# ---------------------------------------------------------------------------

def _encode_pil_image(img: Image.Image) -> str:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


def _pil_from_b64(b64: str) -> Image.Image:
    return Image.open(io.BytesIO(base64.b64decode(b64)))


# ---------------------------------------------------------------------------
# Orientation correction
# ---------------------------------------------------------------------------

def _correct_orientation(img: Image.Image, label: str) -> Image.Image:
    if label == "FLIP_HORIZONTAL":
        return ImageOps.mirror(img)
    if label == "FLIP_VERTICAL":
        return ImageOps.flip(img)
    if label == "ROTATE_180":
        return img.rotate(180)
    return img


# ---------------------------------------------------------------------------
# OpenAI-compatible VLM client
# ---------------------------------------------------------------------------

def _build_client(config: UserParameters) -> OpenAI:
    base_url = config.endpoint_url.replace("/chat/completions", "")
    return OpenAI(base_url=base_url, api_key=config.api_key or "EMPTY")

def _call_vlm(
    client: OpenAI,
    config: UserParameters,
    encoded_image: str,
    mime_type: str,
    prompt: str,
    *,
    max_tokens: int | None = None,
    disable_thinking: bool = False,
) -> str:
    extra_body = {}
    if disable_thinking:
        extra_body["chat_template_kwargs"] = {"enable_thinking": False}

    completion = client.chat.completions.create(
        model=config.model_name,
        max_tokens=max_tokens or config.max_tokens,
        temperature=config.temperature,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:{mime_type};base64,{encoded_image}"},
                    },
                ],
            }
        ],
        extra_body=extra_body or None,
    )
    content = completion.choices[0].message.content
    return content.strip() if content else ""


# ---------------------------------------------------------------------------
# Orientation logger
# ---------------------------------------------------------------------------

def _save_orientation_raw(raw: str, resolved: str, output_dir: str) -> None:
    os.makedirs(output_dir, exist_ok=True)
    log_path = os.path.join(output_dir, "orientation_raw_responses.txt")
    with open(log_path, "a", encoding="utf-8") as fh:
        fh.write(
            f"[{datetime.now().isoformat()}]\n"
            f"  raw      : {raw!r}\n"
            f"  resolved : {resolved}\n"
            f"{'-' * 60}\n"
        )

# ---------------------------------------------------------------------------
# Orientation detection
# ---------------------------------------------------------------------------

def _detect_orientation(
    client: OpenAI,
    config: UserParameters,
    encoded_image: str,
) -> str:
    raw = _call_vlm(
        client,
        config,
        encoded_image,
        mime_type="image/png",
        prompt=ORIENTATION_PROMPT,
        max_tokens=16,
        disable_thinking=True,
    )

    candidate = re.sub(r"[^A-Z0-9_]", "", raw.upper().strip())

    if candidate in ORIENTATION_LABELS:
        _save_orientation_raw(raw, candidate, config.output_dir)
        return candidate

    for label in ORIENTATION_LABELS:
        if label in candidate:
            _save_orientation_raw(raw, f"{label} (fuzzy match)", config.output_dir)
            return label

    _save_orientation_raw(raw, "NONE (unrecognised)", config.output_dir)
    return "NONE"


# ---------------------------------------------------------------------------
# Programmatic form field extraction (AcroForm + XFA)
# ---------------------------------------------------------------------------

def _extract_acroform_fields(file_path: str) -> dict[str, str]:
    fields: dict[str, str] = {}
    try:
        doc = fitz.open(file_path)
        for page in doc:
            for widget in page.widgets():
                name  = widget.field_name or f"unnamed_field_page{page.number}_{widget.rect}"
                value = widget.field_value
                if value is not None and str(value).strip():
                    # Deduplicate: append page number suffix only on collision
                    key = name if name not in fields else f"{name}_p{page.number + 1}"
                    fields[key] = str(value).strip()
        doc.close()
    except Exception as exc:
        fields["__acroform_extraction_error__"] = str(exc)
    return fields


def _extract_xfa_fields(file_path: str) -> dict[str, str]:
    fields: dict[str, str] = {}

    try:
        doc = fitz.open(file_path)

        if hasattr(doc, "xfa_fields"):
            xfa = doc.xfa_fields()
            if xfa:
                doc.close()
                return {k: str(v) for k, v in xfa.items() if v is not None}

        catalog_xref = doc.pdf_catalog()
        catalog_obj  = doc.xref_object(catalog_xref, compressed=False)

        acroform_match = re.search(r"/AcroForm\s+(\d+)\s+\d+\s+R", catalog_obj)
        if acroform_match:
            acroform_xref = int(acroform_match.group(1))
            acroform_obj  = doc.xref_object(acroform_xref, compressed=False)

            xfa_match = re.search(r"/XFA\s+(\d+)\s+\d+\s+R", acroform_obj)
            if xfa_match:
                xfa_xref   = int(xfa_match.group(1))
                xfa_stream = doc.xref_stream(xfa_xref)
                if xfa_stream:
                    fields = _parse_xfa_xml(xfa_stream)

        doc.close()

    except Exception as exc:
        fields["__xfa_extraction_error__"] = str(exc)

    return fields


def _parse_xfa_xml(raw_xml: bytes) -> dict[str, str]:
    fields: dict[str, str] = {}

    xml_fragments: list[bytes] = []

    chunk_starts = [m.start() for m in re.finditer(rb"<(?![\?/!])\w", raw_xml)]
    if len(chunk_starts) <= 1:
        xml_fragments = [raw_xml]
    else:
        xml_fragments = [raw_xml] + [
            raw_xml[chunk_starts[i]:chunk_starts[i + 1]]
            for i in range(len(chunk_starts) - 1)
        ] + [raw_xml[chunk_starts[-1]:]]

    for fragment in xml_fragments:
        try:
            root = ET.fromstring(fragment)
        except ET.ParseError:
            continue

        tag = root.tag.lower()
        if "datasets" not in tag and "data" not in tag:
            continue

        for elem in root.iter():
            text = (elem.text or "").strip()
            if not text:
                continue
            local_tag = re.sub(r"\{[^}]*\}", "", elem.tag)  # strip namespace
            fields[local_tag] = text

        if fields:
            break

    return fields


def _format_form_fields_block(
    acroform: dict[str, str],
    xfa: dict[str, str],
) -> str:
    lines: list[str] = []

    if acroform:
        lines.append("## Programmatically Extracted Form Fields (AcroForm)\n")
        for name, value in acroform.items():
            if name.startswith("__") and name.endswith("__"):
                lines.append(f"> ⚠️ **Extraction warning:** {value}\n")
            else:
                lines.append(f"- **{name}**: {value}")
        lines.append("")

    if xfa:
        lines.append("## Programmatically Extracted Form Fields (XFA)\n")
        for name, value in xfa.items():
            if name.startswith("__") and name.endswith("__"):
                lines.append(f"> ⚠️ **Extraction warning:** {value}\n")
            else:
                lines.append(f"- **{name}**: {value}")
        lines.append("")

    if not lines:
        return ""

    header = (
        "# Fillable Form Fields (Programmatic Extraction)\n\n"
        "> The following values were extracted directly from the PDF's form field "
        "data structures (AcroForm /V entries and/or XFA datasets). "
        "They are guaranteed accurate regardless of whether the appearance stream "
        "was rendered correctly in the visual OCR pass below.\n\n"
    )
    return header + "\n".join(lines) + "\n\n---\n\n"


# ---------------------------------------------------------------------------
# Main pipeline per image
# ---------------------------------------------------------------------------

def _save_debug_crop(img: Image.Image, output_dir: str, tag: str = "") -> str:
    debug_dir = os.path.join(output_dir, "debug_crops")
    os.makedirs(debug_dir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    suffix = f"_{tag}" if tag else ""
    out_path = os.path.join(debug_dir, f"crop{suffix}_{ts}.png")
    img.save(out_path, format="PNG")
    return out_path


def _process_image_bytes(
    client: OpenAI,
    config: UserParameters,
    b64_input: str,
    mime_type: str = "image/png",
    debug_tag: str = "",
) -> tuple[str, str]:
    if mime_type != "image/png":
        b64_target = _encode_pil_image(_pil_from_b64(b64_input))
    else:
        b64_target = b64_input

    orientation = _detect_orientation(client, config, b64_target)

    if orientation != "NONE":
        corrected  = _correct_orientation(_pil_from_b64(b64_target), orientation)
        b64_target = _encode_pil_image(corrected)

    ocr_text = _call_vlm(
        client,
        config,
        b64_target,
        mime_type="image/png",
        prompt=config.prompt,
        disable_thinking=True,
    )

    return ocr_text, orientation


# ---------------------------------------------------------------------------
# PDF and image extraction entry points
# ---------------------------------------------------------------------------

def _pdf_to_png_pages_b64(file_path: str, dpi: int) -> list[str]:
    doc   = fitz.open(file_path)
    pages = []
    mat   = fitz.Matrix(dpi / 72.0, dpi / 72.0)
    for page in doc:
        pix = page.get_pixmap(matrix=mat, alpha=False)
        pages.append(base64.b64encode(pix.tobytes("png")).decode("utf-8"))
    doc.close()
    return pages


def _extract_pdf(file_path: str, config: UserParameters, client: OpenAI) -> str:
    acroform_fields = _extract_acroform_fields(file_path)
    xfa_fields      = _extract_xfa_fields(file_path)
    form_block      = _format_form_fields_block(acroform_fields, xfa_fields)

    pages_b64 = _pdf_to_png_pages_b64(file_path, dpi=config.pdf_dpi)
    if not pages_b64:
        raise RuntimeError("PDF appears to have no pages.")

    page_texts = []
    for page_num, png_b64 in enumerate(pages_b64, start=1):
        ocr_text, orientation = _process_image_bytes(client, config, png_b64, mime_type="image/png", debug_tag=f"{Path(file_path).stem}_p{page_num}")
        header = f"--- Page {page_num}"
        if "NONE" not in orientation:
            header += f" [orientation corrected: {orientation}]"
        header += " ---"
        page_texts.append(f"{header}\n{ocr_text}")

    ocr_output = "\n\n".join(page_texts)

    return form_block + ocr_output


def _extract_image(file_path: str, config: UserParameters, client: OpenAI) -> str:
    ext       = Path(file_path).suffix.lower()
    mime_type = IMAGE_EXTENSIONS[ext]
    with open(file_path, "rb") as fh:
        encoded = base64.b64encode(fh.read()).decode("utf-8")
    ocr_text, _ = _process_image_bytes(client, config, encoded, mime_type, debug_tag=Path(file_path).stem)
    return ocr_text


# ---------------------------------------------------------------------------
# Single-file orchestrator
# ---------------------------------------------------------------------------

def _process_single_file(real_path: str, config: UserParameters) -> dict:
    base_filename = os.path.basename(real_path)
    ext = Path(real_path).suffix.lower()

    if ext not in SUPPORTED_EXTENSIONS:
        return {"file": base_filename, "status": "error", "message": f"Unsupported file type '{ext}'."}

    if os.path.getsize(real_path) / (1024 * 1024) > 50:
        return {"file": base_filename, "status": "error", "message": "File too large. Maximum supported size is 50 MB."}

    client = _build_client(config)

    try:
        extracted_text = _extract_pdf(real_path, config, client) if ext == ".pdf" else _extract_image(real_path, config, client)
    except Exception as exc:
        return {"file": base_filename, "status": "error", "message": str(exc)}

    if not extracted_text.strip():
        return {"file": base_filename, "status": "error", "message": "Model returned an empty response."}

    out_path = _save_artifact(config.output_dir, base_filename, extracted_text)

    return {
        "file":   base_filename,
        "status": "success",
        "artifact": {
            "file_name":         os.path.basename(out_path),
            "char_count":        len(extracted_text),
            "extracted_content": extracted_text,
        },
    }


# ---------------------------------------------------------------------------
# Tool entry point
# ---------------------------------------------------------------------------

def run_tool(config: UserParameters, args: ToolParameters) -> Any:
    # Outputs are written under the tool's session working directory.
    session_dir = config.output_dir
    os.makedirs(session_dir, exist_ok=True)

    # Resolve the input file within the session working directory.
    real_path = _resolve_file_path(args.file_name)

    if not real_path:
        error_msg = (
            f"File '{args.file_name}' not found in the session working directory "
            f"('{os.path.abspath('.')}')."
        )
        return {
            "status": "error",
            "summary": {"total": 1, "succeeded": 0, "failed": 1},
            "results": [{"file": args.file_name, "status": "error", "message": error_msg}],
            "artifact_directory": os.path.abspath(session_dir),
        }

    # Process the successfully resolved file
    result = _process_single_file(real_path, config)
    is_success = result["status"] == "success"

    return {
        "status":  "success" if is_success else "error",
        "summary": {
            "total": 1,
            "succeeded": 1 if is_success else 0,
            "failed": 0 if is_success else 1
        },
        "results": [result],
        "artifact_directory": os.path.abspath(session_dir),
    }


OUTPUT_KEY = "tool_output"

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--user-params", required=True)
    parser.add_argument("--tool-params", required=True)
    cli_args   = parser.parse_args()
    config_obj = UserParameters(**json.loads(cli_args.user_params))
    params_obj = ToolParameters(**json.loads(cli_args.tool_params))
    output     = run_tool(config_obj, params_obj)
    print(OUTPUT_KEY, json.dumps(output, indent=2))
